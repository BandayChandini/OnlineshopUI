import React, { useState, useEffect } from "react";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import { useNavigate } from "react-router-dom";
import './UserDashboard.css';
import img1 from '../../src/logo.jpeg';
const UserDashboard = () => {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [filters, setFilters] = useState({
    productName: "",
    minPrice: "",
    maxPrice: "",
    color: "",
    brand: ""
  });
  const [searchQuery, setSearchQuery] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    fetchProducts();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [filters, searchQuery]);

  const fetchProducts = async () => {
    try {
      const response = await axios.get("http://localhost:5191/api/Product/GetProducts");
      setProducts(response.data);
      setFilteredProducts(response.data);
    } catch (error) {
      console.error("Error fetching products:", error);
      setError("Error fetching products.");
    }
  };

  const handleFilterChange = (e) => {
    setFilters({
      ...filters,
      [e.target.name]: e.target.value
    });
  };

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  const applyFilters = () => {
    const filteredData = products.filter((product) => {
      const productName = product.productName ? product.productName.toLowerCase() : '';
      const color = product.color ? product.color.toLowerCase() : '';
      const brand = product.brand ? product.brand.toLowerCase() : '';

      return (
        (!filters.productName || productName.includes(filters.productName.toLowerCase())) &&
        (!filters.minPrice || product.price >= filters.minPrice) &&
        (!filters.maxPrice || product.price <= filters.maxPrice) &&
        (!filters.color || color.includes(filters.color.toLowerCase())) &&
        (!filters.brand || brand.includes(filters.brand.toLowerCase()))
      );
    });
    setFilteredProducts(filteredData);
  };

  const handleAddToCart = async (productId) => {
    try {
      const userId = localStorage.getItem('userId');
      console.log('User ID:', userId);
      console.log('Product ID:', productId);
  
      if (!userId) {
        setError("User not logged in.");
        return;
      }
  
      const cartItem = {
        cartItemId:'',
        productId: productId,
        userId: userId,
        price:0,
        quantity: 1,
        totalPrice:0
      };
  
      const response = await axios.post("http://localhost:5191/api/CartItem/AddCartItem", cartItem);
      console.log('Response:', response);
  
      if (response.status === 201) {
        console.log(`Product ${productId} added to cart successfully`);
        navigate('/cart');
      } else {
        setError("Failed to add product to cart.");
      }
    } catch (error) {
      console.error("Error adding product to cart:", error);
      setError("An error occurred while adding the product to the cart.");
    }
  };
  

  const handleGoHome = () => {
    navigate('/');
  };

  const handleApplyFilters = (e) => {
    e.preventDefault();
    applyFilters();
  };

  const finalFilteredProducts = filteredProducts.filter(product =>
    product.productName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="user-dashboard d-flex flex-column min-vh-100">
      {/* Header */}
      <header className="bg-dark text-white text-center py-3 shadow-sm">
        <h1>User Dashboard</h1>
        <button className="btn btn-secondary mt-3" onClick={handleGoHome}>
          Back to Home Page
        </button>
      </header>

      {/* Main Content */}
      <div className="d-flex">
        {/* Sidebar */}
        <aside className="sidebar bg-light p-4">
          <h4>Filter Products</h4>
          <form onSubmit={handleApplyFilters}>
            <div className="form-group mb-3">
              <input
                type="text"
                className="form-control"
                placeholder="Product Name"
                name="productName"
                value={filters.productName}
                onChange={handleFilterChange}
              />
            </div>
            <div className="form-group mb-3">
              <input
                type="number"
                className="form-control"
                placeholder="Min Price"
                name="minPrice"
                value={filters.minPrice}
                onChange={handleFilterChange}
              />
            </div>
            <div className="form-group mb-3">
              <input
                type="number"
                className="form-control"
                placeholder="Max Price"
                name="maxPrice"
                value={filters.maxPrice}
                onChange={handleFilterChange}
              />
            </div>
            <div className="form-group mb-3">
              <input
                type="text"
                className="form-control"
                placeholder="Color"
                name="color"
                value={filters.color}
                onChange={handleFilterChange}
              />
            </div>
            <div className="form-group mb-3">
              <input
                type="text"
                className="form-control"
                placeholder="Brand"
                name="brand"
                value={filters.brand}
                onChange={handleFilterChange}
              />
            </div>
            <button type="submit" className="btn btn-primary">Apply Filters</button>
          </form>
        </aside>

        {/* Product List */}
        <main className="container mt-4">
          {error && <div className="alert alert-danger">{error}</div>}

          {/* Search Bar */}
          <div className="mb-4">
            <input
              type="text"
              className="form-control"
              placeholder="Search Products..."
              value={searchQuery}
              onChange={handleSearchChange}
            />
          </div>

          <section className="product-list card">
            <div className="card-header bg-success text-white">
              <h3>Product List</h3>
            </div>
            <div className="card-body table-responsive">
              <table className="table table-striped table-bordered">
                <thead>
                  <tr>
                    <th>Product Name</th>
                    <th>Brand</th>
                    <th>Price</th>
                    <th>Color</th>
                    <th>Image</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {finalFilteredProducts.length > 0 ? (
                    finalFilteredProducts.map((product) => (
                      <tr key={product.productId}>
                        <td>{product.productName}</td>
                        <td>{product.brand}</td>
                        <td>${product.price}</td>
                        <td>{product.color}</td>
                        <td>
                          <img
                            src={img1}
                            alt={product.productName}
                            style={{ width: "100px" }}
                          />
                        </td>
                        <td>
                          <button
                            className="btn btn-primary btn-sm"
                            onClick={() => handleAddToCart(product.productId)}
                          >
                            Add to Cart
                          </button>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="7" className="text-center">
                        No products found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </section>
        </main>
      </div>

      {/* Footer */}
      <footer className="bg-dark text-white text-center py-3 mt-auto">
        <div className="container">
          <p className="mb-0">&copy; 2024 ShopEase. All rights reserved.</p>
          <div>
            <a href="#" className="text-white me-2">Facebook</a>
            <a href="#" className="text-white me-2">Twitter</a>
            <a href="#" className="text-white">Instagram</a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default UserDashboard;
