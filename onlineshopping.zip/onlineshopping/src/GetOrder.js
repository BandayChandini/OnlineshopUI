import { useState, useEffect } from "react";
import axios from "axios";

const GetOrders = () => {
  const [items, setItems] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:5191/api/Order/GetOrders")
      .then((response) => {
        console.log(response.data);
        setItems(response.data); // adding response data to items
      })
      .catch((error) => console.log(error));
  }, []);

  const handleRemove = (orderId) => {
    console.log(orderId);
    axios
      .delete('http://localhost:5191/api/Order/DeleteOrder?id='+orderId)
      .then((res) => {
        // Optional: You can update the state to remove the deleted item from the UI
        setItems((prevItems) => prevItems.filter(item => item.orderId !== orderId));
      })
      .catch((err) => console.log(err));
  };
  

  return (
    <div className="container">
      <form>
        <table className="table table-bordered table-hover">
          <thead className="table-primary">
            <tr>
              <td>address</td>
              <td>price</td>
              <td>totalprice</td>
              <td>orderStatus</td>
              <td>deliveryDate</td>
              <td>orderDate</td>
              <td>Actions</td>
            </tr>
          </thead>
          <tbody>
            {items.map((item) => (
              <tr key={item.orderId}>
                <td>{item.orderId}</td>
                <td>{item.address}</td>
                <td>{item.price}</td>
                <td>{item.totalprice}</td>
                <td>{item.deliveryDate}</td>
                <td>{item.orderDate}</td>
                <td>
                  <button type="button" onClick={() => handleRemove(item.orderId)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </form>
    </div>
  );
};

export default GetOrders;
