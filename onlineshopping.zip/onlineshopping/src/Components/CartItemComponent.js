
import React, { useState, useEffect } from "react";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import { useNavigate } from "react-router-dom";
import './CartItem.css'; // Custom styles for CartItem component

const CartItem = () => {
  const [cartItems, setCartItems] = useState([]);
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const userId = localStorage.getItem("userId"); // Fetch user ID from local storage

  useEffect(() => {
    if (userId) {
      fetchCartItems();
    } else {
      setError("User ID not found. Please log in.");
    }
  }, [userId]);

  const fetchCartItems = async () => {
    try {
      const response = await axios.get(`http://localhost:5191/api/CartItem/GetCartItemsByUserIdDTO/${userId}`);
      console.log("Fetched cart items:", response.data); // Debugging line
      setCartItems(response.data);
    } catch (error) {
      console.error("Error fetching cart items:", error);
      setError("Error fetching cart items.");
    }
  };

  const handleCheckout = () => {
    navigate('/checkout'); // Redirect to Checkout page
  };

  const handleRemoveItem = (cartItemId) => {
    axios.delete(`http://localhost:5191/api/CartItem/DeleteCartItem?id=${cartItemId}`)
      .then(() => fetchCartItems()) // Refresh cart items
      .catch((error) => {
        console.error("Error removing item from cart:", error);
        alert("Failed to remove item from cart.");
      });
  };

  const handleQuantityChange = (cartItemId, newQuantity) => {
    const updatedCartItems = cartItems.map(item =>
      item.cartItemId === cartItemId ? { ...item, quantity: newQuantity, totalPrice: item.price * newQuantity } : item
    );
    setCartItems(updatedCartItems);
  };

  const handleAddToCart = (product) => {
    const existingCartItem = cartItems.find(item => item.productId === product.productId);
    if (existingCartItem) {
      // Update quantity if product is already in the cart
      handleQuantityChange(existingCartItem.cartItemId, existingCartItem.quantity + 1);
    } else {
      // Add new product to cart
      const newCartItem = {
        ...product,
        cartItemId: `C${new Date().getTime()}`,
        quantity: 1,
        totalPrice: product.price
      };
      setCartItems([...cartItems, newCartItem]);
    }
  };

  return (
    <div className="cart-item d-flex flex-column min-vh-100">
      {/* Header */}
      <header className="bg-dark text-white text-center py-3 shadow-sm">
        <h1>Shopping Cart</h1>
        <button className="btn btn-secondary mt-3" onClick={() => navigate('/')}>
          Back to Home Page
        </button>
      </header>

      {/* Main Content */}
      <div className="container mt-4">
        {error && <div className="alert alert-danger">{error}</div>}

        <section className="cart-list card">
          <div className="card-header bg-success text-white">
            <h3>Cart Items</h3>
          </div>
          <div className="card-body table-responsive">
            <table className="table table-striped table-bordered">
              <thead>
                <tr>
                  <th>Product Name</th>
                  <th>Brand</th>
                  <th>Price</th>
                  <th>Quantity</th>
                  <th>Total Price</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {cartItems.length > 0 ? (
                  cartItems.map((item) => (
                    <tr key={item.cartItemId}>
                      <td>{item.productName}</td>
                      <td>{item.brand}</td>
                      <td>${item.price}</td>
                      <td>
                        <input
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={(e) => handleQuantityChange(item.cartItemId, parseInt(e.target.value))}
                          className="form-control"
                        />
                      </td>
                      <td>${item.totalPrice.toFixed(2)}</td>
                      <td>
                        <button
                          className="btn btn-danger btn-sm"
                          onClick={() => handleRemoveItem(item.cartItemId)}
                        >
                          Remove
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="6" className="text-center">
                      No items in cart.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
            {cartItems.length > 0 && (
              <button className="btn btn-primary mt-3" onClick={handleCheckout}>
                Proceed to Checkout
              </button>
            )}
          </div>
        </section>
      </div>

      {/* Footer */}
      <footer className="bg-dark text-white text-center py-3 mt-auto">
        <div className="container">
          <p>&copy; 2024 Online Shopping System. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default CartItem;
