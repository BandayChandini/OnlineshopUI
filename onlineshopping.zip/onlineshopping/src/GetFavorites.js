import { useState, useEffect } from "react";
import axios from "axios";

const GetFavorites = () => {
  const [items, setItems] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:5191/api/Favorite/GetFavorites")
      .then((response) => {
        console.log(response.data);
        setItems(response.data); // adding response data to items
      })
      .catch((error) => console.log(error));
  }, []);

  const handleRemove = (favoriteId) => {
    console.log(favoriteId);
    axios
      .delete('http://localhost:5191/api/Favorite/DeleteFavorite?id='+favoriteId)
      .then((res) => {
        // Optional: You can update the state to remove the deleted item from the UI
        setItems((prevItems) => prevItems.filter(item => item.favoriteId !== favoriteId));
      })
      .catch((err) => console.log(err));
  };
  

  return (
    <div className="container">
      <form>
        <table className="table table-bordered table-hover">
          <thead className="table-primary">
            <tr>
              <td>favoriteId</td>
              <td>userId</td>
              <td>productId</td>
              
              <td>Actions</td>
            </tr>
          </thead>
          <tbody>
            {items.map((item) => (
              <tr key={item.favoriteId}>
                <td>{item.favoriteId}</td>
                <td>{item.favoriteName}</td>
                <td>{item.productId}</td>
                <td>
                  <button type="button" onClick={() => handleRemove(item.favoriteId)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </form>
    </div>
  );
};

export default GetFavorites;
