import { useState } from "react"
import axios from "axios"
const AddOrder=()=>{
    const[order,setOrder]=useState({
        address:'',
        price:0,
        totalprice:'',
        orderStatus:'',
        deliveryDate:'',
        orderDate:'',
    })
    const save=(e)=>{
        e.preventDefault();
        console.log(order);
        axios
        .post("http://localhost:5191/api/Order/AddOrder",order)
        .then((res)=>{
             console.log(res.data)
        })
        .catch((err)=>console.log(err));
       
    };

    return(
        <div className="container">
            <form onSubmit={save}>
                <table className="table">
                    <tbody>
                    <tr>
                        <td>Address</td>
                        <td>
                            <input type="text" value={order.address} onChange={(e)=>setOrder((prevObj)=>({
                                ...prevObj,address:e.target.value,
                            }))} />
                        </td>
                    </tr>
                    <tr>
                        <td>productName</td>
                        <td>
                            <input type="text" value={product.productName} onChange={(e)=>setProduct((prevObj)=>({
                                ...prevObj,productName:e.target.value,
                            }))} />
                        </td>
                    </tr>
                    <tr>
                        <td>Price</td>
                        <td>
                            <input type="number" value={product.price} onChange={(e)=>setProduct((prevObj)=>({
                                ...prevObj,price:e.target.value
                            }))} />
                        </td>
                    </tr>
                    <tr>
                        <td>CategoryId</td>
                        <td>
                            <input type="text" value={product.categoryId} onChange={(e)=>setProduct((prevObj)=>({
                                ...prevObj,categoryId:e.target.value,
                            }))} />
                        </td>
                    </tr>
                    <tr>
                        <td>color</td>
                        <td>
                            <input type="text" value={product.color} onChange={(e)=>setProduct((prevObj)=>({
                                ...prevObj,color:e.target.value,
                            }))} />
                        </td>
                    </tr>
                   
                    <tr>
                        <td>Size</td>
                        <td>
                            <input type="text" value={product.size} onChange={(e)=>setProduct((prevObj)=>({
                                ...prevObj,size:e.target.value,
                            }))} />
                        </td>
                    </tr>
                    <tr>
                        <td>Brand</td>
                        <td>
                            <input type="text" value={product.brand} onChange={(e)=>setProduct((prevObj)=>({
                                ...prevObj,brand:e.target.value,
                            }))} />
                        </td>
                    </tr>
                    </tbody>
                </table>
                <button type="submit">AddProduct</button>

            </form>

        </div>
    )


}
export default AddProduct;