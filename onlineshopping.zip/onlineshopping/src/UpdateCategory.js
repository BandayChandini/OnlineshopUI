import { useState,useEffect } from "react"
import axios from "axios"
const UpdateCategory=()=>{
    const[category,setCategory]=useState({
        categoryId:'',
        categoryName:'',
        Description:"",
    })

      const [err, setError] = useState("");
    const save=(e)=>{
        e.preventDefault();
        console.log(category);
        axios
        .put("http://localhost:5191/api/Category/EditCategory",category)
        .then((res)=>{
             console.log(res.data)
        })
        .catch((err)=>console.log(err));
       
    };

   

      const search = (e) => {
        let categoryId = category.categoryId;
        console.log(categoryId);
        axios
          .get("http://localhost:5191/api/Category/GetCategory/" + categoryId)
          .then((res) => {
            console.log(res);
            if (res.statusText !== "No Content") setCategory(res.data);
            else {
              setError("Invalid Id");
            }
          });
        e.preventDefault();
      };
      const searchByName = (e) => {
        let categoryName = category.categoryName;
        console.log(categoryName);
        axios
            .get("http://localhost:5191/api/Category/GetCategoryByName/" + categoryName)
            .then((res) => {
                console.log(res);
                if (res.statusText !== "No Content") setCategory(res.data);
                else {
                    setError("Category not found");
                }
            })
            .catch((err) => console.log(err));
        e.preventDefault();
    };

    return(
        <div className="container">
            <form onSubmit={save}>
                <table className="table">
                    <tbody>
                    <tr>
                        <td>CategoryId</td>
                        <td>
                            <input type="text" value={category.categoryId} onChange={(e)=>setCategory((prevObj)=>({
                                ...prevObj,categoryId:e.target.value,
                            }))}  readonly />
                        </td>
                    </tr>
                    <tr>
                        <td>categoryName</td>
                        <td>
                            <input type="text" value={category.categoryName} onChange={(e)=>setCategory((prevObj)=>({
                                ...prevObj,categoryName:e.target.value,
                            }))} />
                        </td>
                    </tr>
                    <tr>
                        <td>Description</td>
                        <td>
                            <input type="text" value={category.description} onChange={(e)=>setCategory((prevObj)=>({
                                ...prevObj,description:e.target.value
                            }))} />
                        </td>
                    </tr>
                    </tbody>
                </table>
                <button type="submit">Edit</button>
             
                <button onClick={search}>Search</button>
                <button onClick={searchByName}>SearchByName</button>

            </form>

        </div>
    )


}
export default UpdateCategory;