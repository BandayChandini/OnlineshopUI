import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import './HomePage.css'; // Custom CSS file for additional styling

const HomePage = () => {
  const [items, setItems] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate(); // Initialize useNavigate

  useEffect(() => {
    axios
      .get("http://localhost:5191/api/Product/GetProducts")
      .then((response) => {
        setItems(response.data);
        setLoading(false);
      })
      .catch((error) => {
        console.error(error);
        setError("Failed to load products.");
        setLoading(false);
      });

    const handleScroll = () => {
      const navbar = document.querySelector(".navbar");
      if (window.scrollY > 50) {
        navbar.classList.add("scrolled");
      } else {
        navbar.classList.remove("scrolled");
      }
    };

    window.addEventListener("scroll", handleScroll);

    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const filteredItems = items.filter(item =>
    item.productName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAddToCart = (productId) => {
    const cartItem = {
      productId: productId,
      quantity: 1, // Default quantity
    };

    axios
      .post("http://localhost:5191/api/CartItem/AddCartItem", cartItem)
      .then(() => {
        alert("Product added to cart!");
        navigate('/cart'); // Navigate to the cart page after adding the product
      })
      .catch((error) => {
        console.error("Error adding product to cart:", error);
        alert("Failed to add product to cart.");
      });
  };

  return (
    <div className="d-flex flex-column min-vh-100 bg-light">
      {/* Navigation Bar */}
      <nav className="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm animated-navbar">
        <div className="container-fluid">
          <input
            type="text"
            className="form-control w-50 ms-3 shadow-sm search-input"
            placeholder="Search for products..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav ms-auto">
              <li className="nav-item">
                <Link className="nav-link text-white" to="/">
                  Home
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link text-white" to="/login">
                  Login
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link text-white" to="/register">
                  Register
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>

      {/* Static Image */}
      <div className="hero-section">
        <img
          src="https://via.placeholder.com/1200x400/5A9/FFF?text=Discover+Our+Collections"
          alt="Discover Our Collections"
          className="img-fluid w-100"
          loading="lazy"
        />
        <div className="hero-caption text-center">
          <h3 className="animated-title text-white">Discover Our Collections</h3>
          <p className="animated-text text-white">Explore a wide range of high-quality products.</p>
        </div>
      </div>

      {/* Featured Products */}
      <div className="container mt-5">
        <h2 className="text-center mb-4 text-primary animate_animated animate_fadeIn">Featured Products</h2>
        {loading ? (
          <div className="text-center">
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        ) : error ? (
          <p className="text-center text-danger animate_animated animate_shakeX">{error}</p>
        ) : (
          <div className="row">
            {filteredItems.length > 0 ? (
              filteredItems.map((item) => (
                <div className="col-md-3 mb-4" key={item.productId}>
                  <div className="card border-0 shadow h-100 transition-card">
                    <img
                      src={item.imageUrl || "/default-image.jpg"}
                      className="card-img-top rounded-top"
                      alt={item.productName}
                      loading="lazy"
                    />
                    <div className="card-body text-center">
                      <h5 className="card-title">{item.productName}</h5>
                      <p className="card-text">${item.price.toFixed(2)}</p>
                      <button
                        className="btn btn-primary"
                        onClick={() => handleAddToCart(item.productId)}
                      >
                        Add to Cart
                      </button>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-center">No products found.</p>
            )}
          </div>
        )}
      </div>

      {/* Promotional Banner */}
      <div className="promotional-banner text-center py-5 bg-warning text-dark">
        <h2>Special Offer</h2>
        <p>Get 20% off on your first purchase! Use code <strong>SAVE20</strong> at checkout.</p>
        <Link to="/shop" className="btn btn-dark">Shop Now</Link>
      </div>

      {/* Footer */}
      <footer className="footer bg-dark text-white text-center py-3">
        <p>&copy; 2024 Your Online Store. All rights reserved.</p>
        <p>
          <Link to="/about" className="text-white">About Us</Link> | 
          <Link to="/contact" className="text-white">Contact</Link> | 
          <Link to="/help" className="text-white">Help</Link> | 
          <Link to="/mailus" className="text-white">Mail Us</Link>
        </p>
      </footer>
    </div>
  );
};

export default HomePage;