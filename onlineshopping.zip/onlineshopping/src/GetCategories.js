import { useState, useEffect } from "react";
import axios from "axios";

const GetCategories = () => {
  const [items, setItems] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:5191/api/Category/GetAllCategories")
      .then((response) => {
        console.log(response.data);
        setItems(response.data); // adding response data to items
      })
      .catch((error) => console.log(error));
  }, []);

  const handleRemove = (categoryId) => {
    console.log(categoryId);
    axios
      .delete('http://localhost:5191/api/Category/DeleteCategory?id='+categoryId)
      .then((res) => {
        // Optional: You can update the state to remove the deleted item from the UI
        setItems((prevItems) => prevItems.filter(item => item.categoryId !== categoryId));
      })
      .catch((err) => console.log(err));
  };
  return (
    <div className="container">
      <form>
        <table className="table table-bordered table-hover">
          <thead className="table-primary">
            <tr>
              <td>CategoryId</td>
              <td>categoryName</td>
              <td>Description</td>
              <td>Actions</td>
            </tr>
          </thead>
          <tbody>
            {items.map((item) => (
              <tr key={item.categoryId}>
                <td>{item.categoryId}</td>
                <td>{item.categoryName}</td>
                <td>{item.description}</td>
                <td>
                  <button type="button" onClick={() => handleRemove(item.categoryId)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </form>
    </div>
  );
};

export default GetCategories;
