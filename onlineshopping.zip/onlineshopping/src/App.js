import "./App.css";
import Login from "./Home page/Login";
import UserDashboard from "./User/user-dashboard";
import AdminDashboard from "./Admin/AdminDashboard";
import { BrowserRouter, Route, Routes,Navigate } from "react-router-dom";
import Register from "./Home page/Register";
import HomePage from "./Home page/HomePage";
import CartItem from "./Components/CartItemComponent";




function App() {
  return (
    <div className="App">
<BrowserRouter>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/user-dashboard" element={<UserDashboard />} />
        <Route path="/admin-dashboard" element={<AdminDashboard />} />
        <Route path="/cart" element={<CartItem />} />
        {/* Redirect to home page if no match */}
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </BrowserRouter>
    </div>
  );
  
}

export default App;
