import React, { useState, useEffect } from "react";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import { Link, useNavigate } from "react-router-dom";
import './AdminDashboard.css';

const AdminDashboard = () => {
  const [products, setProducts] = useState([]);
  const [newProduct, setNewProduct] = useState({
    productId: "",
    productName: "",
    price: 0,
    categoryId: "",
    color: "",
    imageURL: "",
    brand: ""
  });
  const [editingProduct, setEditingProduct] = useState(null);
  const [editProduct, setEditProduct] = useState({});
  const [error, setError] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await axios.get("http://localhost:5191/api/Product/GetProducts");
      setProducts(response.data);
    } catch (error) {
      console.error("Error fetching products:", error);
      setError("Error fetching products.");
    }
  };

  const handleAddProduct = async () => {
    try {
      await axios.post("http://localhost:5191/api/Product/AddProduct", newProduct);
      fetchProducts();
      setNewProduct({
        productId: "",
        productName: "",
        price: 0,
        categoryId: "",
        color: "",
        imageURL: "",
        brand: ""
      });
    } catch (error) {
      console.error("Error adding product:", error);
      setError("Error adding product.");
    }
  };

  const handleEditProduct = async () => {
    try {
      await axios.put("http://localhost:5191/api/Product/EditProduct", editProduct);
      fetchProducts();
      setEditingProduct(null);
      setEditProduct({});
    } catch (error) {
      console.error("Error updating product:", error);
      setError("Error updating product.");
    }
  };

  const handleDeleteProduct = async (productId) => {
    try {
      await axios.delete(`http://localhost:5191/api/Product/DeleteProduct/${productId}`);
      fetchProducts();
    } catch (error) {
      console.error("Error deleting product:", error);
      setError("Error deleting product.");
    }
  };

  const handleEditClick = (product) => {
    setEditingProduct(product.productId);
    setEditProduct({ ...product });
  };

  const handleGoHome = () => {
    navigate('/'); // Redirect to the Home Page
  };

  return (
    <div className="admin-dashboard d-flex flex-column min-vh-100">
      {/* Header */}
      <header className="bg-dark text-white text-center py-3 shadow-sm">
        <h1>Admin Dashboard</h1>
        <button className="btn btn-secondary mt-3" onClick={handleGoHome}>
          Back to Home Page
        </button>
      </header>

      {/* Main Content */}
      <main className="container mt-4">
        {error && <div className="alert alert-danger">{error}</div>}

        {/* Add Product Section */}
        <section className="add-product card mb-4">
          <div className="card-header bg-primary text-white">
            <h3>Add New Product</h3>
          </div>
          <div className="card-body">
            <form>
              <div className="form-group mb-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Product Name"
                  value={newProduct.productName}
                  onChange={(e) => setNewProduct({ ...newProduct, productName: e.target.value })}
                />
              </div>
              <div className="form-group mb-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Brand"
                  value={newProduct.brand}
                  onChange={(e) => setNewProduct({ ...newProduct, brand: e.target.value })}
                />
              </div>
              <div className="form-group mb-3">
                <input
                  type="number"
                  className="form-control"
                  placeholder="Price"
                  value={newProduct.price}
                  onChange={(e) => setNewProduct({ ...newProduct, price: parseFloat(e.target.value) })}
                />
              </div>
              <div className="form-group mb-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Category ID"
                  value={newProduct.categoryId}
                  onChange={(e) => setNewProduct({ ...newProduct, categoryId: e.target.value })}
                />
              </div>
              <div className="form-group mb-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Color"
                  value={newProduct.color}
                  onChange={(e) => setNewProduct({ ...newProduct, color: e.target.value })}
                />
              </div>
              <div className="form-group mb-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Image URL"
                  value={newProduct.imageURL}
                  onChange={(e) => setNewProduct({ ...newProduct, imageURL: e.target.value })}
                />
              </div>
              <button
                type="button"
                className="btn btn-primary"
                onClick={handleAddProduct}
              >
                Add Product
              </button>
            </form>
          </div>
        </section>

        {/* Edit Product Section */}
        {editingProduct && (
          <section className="edit-product card mb-4">
            <div className="card-header bg-warning text-white">
              <h3>Edit Product</h3>
            </div>
            <div className="card-body">
              <form>
                <div className="form-group mb-3">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Product Name"
                    value={editProduct.productName}
                    onChange={(e) => setEditProduct({ ...editProduct, productName: e.target.value })}
                  />
                </div>
                <div className="form-group mb-3">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Brand"
                    value={editProduct.brand}
                    onChange={(e) => setEditProduct({ ...editProduct, brand: e.target.value })}
                  />
                </div>
                <div className="form-group mb-3">
                  <input
                    type="number"
                    className="form-control"
                    placeholder="Price"
                    value={editProduct.price}
                    onChange={(e) => setEditProduct({ ...editProduct, price: parseFloat(e.target.value) })}
                  />
                </div>
                <div className="form-group mb-3">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Category ID"
                    value={editProduct.categoryId}
                    onChange={(e) => setEditProduct({ ...editProduct, categoryId: e.target.value })}
                  />
                </div>
                <div className="form-group mb-3">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Color"
                    value={editProduct.color}
                    onChange={(e) => setEditProduct({ ...editProduct, color: e.target.value })}
                  />
                </div>
                <div className="form-group mb-3">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Image URL"
                    value={editProduct.imageURL}
                    onChange={(e) => setEditProduct({ ...editProduct, imageURL: e.target.value })}
                  />
                </div>
                <button
                  type="button"
                  className="btn btn-info"
                  onClick={handleEditProduct}
                >
                  Update Product
                </button>
                <button
                  type="button"
                  className="btn btn-secondary ms-2"
                  onClick={() => setEditingProduct(null)}
                >
                  Cancel
                </button>
              </form>
            </div>
          </section>
        )}

        {/* Product List Section */}
        <section className="product-list card">
          <div className="card-header bg-success text-white">
            <h3>Product List</h3>
          </div>
          <div className="card-body table-responsive">
            <table className="table table-striped table-bordered">
              <thead>
                <tr>
                  <th>Product Name</th>
                  <th>Brand</th>
                  <th>Price</th>
                  <th>Category ID</th>
                  <th>Color</th>
                  <th>Image URL</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
              {products.length ? (
  products.map(product => (
    <tr key={product.productId}>
      <td>{product.productName}</td>
      <td>{product.brand}</td>
      <td>${product.price.toFixed(2)}</td> {/* Format price to 2 decimal places */}
      <td>{product.categoryId}</td> {/* Consider mapping to category names */}
      <td>{product.color}</td>
      <td>
        <img
          src={product.imageURL}
          alt={product.productName}
          style={{ width: "100px", height: "auto" }} // Ensure images are appropriately sized
        />
      </td>
      <td>
        <button
          className="btn btn-warning btn-sm me-2"
          onClick={() => handleEditClick(product)}
        >
          Edit
        </button>
        <button
          className="btn btn-danger btn-sm"
          onClick={() => handleDeleteProduct(product.productId)}
        >
          Delete
        </button>
      </td>
    </tr>
  ))
) : (
  <tr>
    <td colSpan="7" className="text-center">No products found.</td>
  </tr>
)}

              </tbody>
            </table>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-dark text-white text-center py-3 mt-auto">
        <div className="container">
          <p className="mb-0">&copy; 2024 ShopEase. All rights reserved.</p>
          <div>
            <a href="#" className="text-white me-2">Facebook</a>
            <a href="#" className="text-white me-2">Twitter</a>
            <a href="#" className="text-white">Instagram</a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default AdminDashboard;
